const showMoreBtn = document.querySelector('.show-more-btn');
const showLessBtn = document.querySelector('.show-less-btn');
const paragraphs = document.querySelectorAll('.container');

let clicked = 0;

showMoreBtn.addEventListener('click', () => {
  clicked++;
  paragraphs.forEach((container, index) => {
    if (clicked >= index) {
      container.classList.remove('hide');
    } else {
      container.classList.add('hide');
    }
  });
let n=(paragraphs.length)-1;
  if (clicked == n) {
    showMoreBtn.classList.add('hide');
    showLessBtn.classList.remove('hide');
  }
});

showLessBtn.addEventListener('click', () => {
  clicked--;
  paragraphs.forEach((container, index) => {
    if (clicked >= index) {
      container.classList.remove('hide');
    } else {
      container.classList.add('hide');
    }
  });

  if (clicked <= 0) {
    showLessBtn.classList.add('hide');
    showMoreBtn.classList.remove('hide');
  }
 
});